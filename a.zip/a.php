<?php


echo system('whoami');
?>